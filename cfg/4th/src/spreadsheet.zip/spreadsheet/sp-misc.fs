

\ : defined  ( c-adr len -- flag)
\   pad place  pad  find  nip ;

: defined  ( "name" -- flag)
  BL word  find  nip ;


: not  s" 0=" evaluate ; immediate

: -rot  s" rot rot" evaluate ;  immediate


\  Confine n within min and max.
: clamp ( n min max -- n' ) rot min max ;

: pairs+  { a b c d -- a+c b+d }
  a c +  b d + ;

: pairs-  { a b c d -- a-c b-d }
  a c -  b d - ;



: beep 149 emit ;


: tidy ( n1 n2 -- larger+1 smaller) 2dup max 1+ -rot min ;

\ For do-loops.
: upto ( low high -- high+1 low)  1+ swap
  2dup < abort" Bad do-loop indices." ;

: is-alpha ( c -- flag) toupper [char] A [ char Z 1+ ] literal within ;
: is-digit ( c -- flag) [char] 0 [ char 9 1+ ] literal within ;

\ by Wil Baden: IF <word> THEN
: ??
  s" if" evaluate BL word count evaluate  s" then" evaluate ;
  immediate



\ 0 value a-reg
\ : ca@-  a-reg c@  -1 +to a-reg ;

\ Fetch a byte and decrement address on stack.
\ Make it a macro.
: c@--  ( adr1 -- adr2 c)
  s" dup 1- swap c@" evaluate ; immediate

\ Decrement & dup. address; fetch byte.
: c--@  ( adr1 -- adr2 c)
  s" 1- dup c@" evaluate ; immediate


: APPEND-CHAR ( char s-adr --)  DUP >R  COUNT  DUP 1+ R> C!  +  C! ;

\ Insert a string within a string.  Allow insertion at a point
\ past the end of the original string---in which case it is to be hoped
\ that the memory area has already been filled with blanks.
: insert   0 0 { adr1 len1 adr2 p     len2 adr3 -- }
  adr2 c@ to len2
  adr2 1+ p +  to adr3
  adr3  dup len1 +  len2 p -  0 max  cmove>
  adr1 adr3 len1 cmove
  len2 p max  len1 +  adr2 c! ;


\ : append   2dup 2>r  count +  swap move  2r> dup c@ rot + swap c! ;
\ Append a string to another string.
: append  ( c-adr len s-adr --)
  2dup 2>r  count +  swap move  2r> dup c@  under+    c! ;


\ Remove leading spaces.
: -leading  BL  skip  ;

\ Convert signed integer to string.
: >str  ( n -- cadr len) dup abs s>d  <# #s rot sign #> ;


\ Find character in string.  First position is 0; -1 means not found.
: cfind   { c adr len -- n }  -1
  adr len bounds ?do i c@ c = if drop i adr - leave then loop ;



: yn ( -- 'Y|'N )
  0
  begin
    drop
    ekey
    dup
    toupper
    dup
    [char] Y =  swap
    [char] N =  or
  until
  dup toupper swap emit ;


\ Allow the user to edit a string.
: edit-adr  { str_adr maxlen -- }
  str_adr count maxlen swap edit-line
  str_adr  c! ;



\ : get-num  ( maxdigits -- n flag)
\   pad swap accept pad swap
\   -trailing dup
\   if  0. 2swap  >number   nip
\     if s" Bad integer." s" " error  2drop  0 0  else  d>s -1 then
\   else  2drop  0 0  then ;


\ \ Parse 1 or more numbers separated by spaces.
\ : parse-nums ( cadr len wanted -- n1 ... flag )
\    0 0 1 { wanted       len err neg }
\   -trailing
\   begin
\     wanted
\   while
\     -leading   1 to neg
\     over c@   [char] -  = if  1 /string  -1 to neg  then
\     dup  to len
\     len
\     if   0. 2swap  >number
\       dup len =  err + to err
\       2swap  d>s
\     else  0  err 1- to err
\     then
\     neg *   -rot
\     wanted 1- to wanted
\   repeat
\   2drop  err 0=  ;


\ Parse 1 or more numbers separated by spaces.
\ If number begins with minus sign, it need not be preceded by space.
: parse-nums ( cadr len wanted -- n1 ... count|flag )
  0 0 1 0 { wanted       len err neg counter }
  -trailing
  begin
    counter 1+ to counter
    1 to neg
    -leading
    dup
    if
      over c@ [char] - = if  1 /string  -1 to neg  then
    endif
    dup  to len
    0. 2swap  >number
    2swap  d>s
    neg *   -rot
    dup len =
  until
  2drop  drop
  counter 1- to counter
  wanted
  if     wanted counter <=
    if
      counter wanted  ?do   drop   loop
      -1
    else
      wanted counter   do   0   loop
      0
    endif
  else    counter
  endif
;


\ Build string displaying two unsigned numbers with space between.
: 2>str ( u1 u2 -- cadr len)
  s>d  <#  #s bl hold 2drop s>d #s  #>  ;


defined +to  not
[if]

create +to_pad 128 allot

\ Add a number to a local variable or value.
\ Pad may be in use, so we use +to_pad.
: +to  ( n "name" --)
\   parse-word   \ Gforth.
  BL parse
  2dup evaluate
  state @
  if
    postpone +
  else  ( n1 c-addr len n2)
    >r rot r> + -rot
  endif
  s" to " +to_pad place
  +to_pad append
  +to_pad count  evaluate
; immediate

[then]


\ \\  This version should be a tad faster when not compiling.

\ \ Add a number to a local variable or value.
\ \ Pad may be in use, so we use +to_pad.
\ : +to  ( n "name" --)
\   state @
\   if
\     parse-word   \ Gforth. Equivalent to ANS "BL parse".
\     2dup evaluate
\     postpone +
\   else
\     >r
\     parse-word
\     2dup evaluate
\     ( c-adr len n)
\     r>  +  -rot
\   endif
\   s" to " +to_pad place
\   +to_pad append
\   +to_pad count  evaluate
\ ; immediate


\ : remaining >IN @ SOURCE 2 PICK - -ROT + SWAP
\   CR ." ->" TYPE ." <-" ; IMMEDIATE

\ This version doesn't work unless you're compiling. I don't know why.
\ : +to  ( n "name" --)
\   >in @
\   >r
\     parse-word   \ Gforth. Equivalent to ANS "BL parse".
\   r>
\   >in !
\   evaluate
\   state @
\   if
\     postpone +
\   else  ( n1 n2)
\     +
\   endif
\   postpone to
\ ; immediate


\ Make a string containing u copies of character c.
: copies  ( u c -- c-adr len )
  swap
  <#   0 ?do  dup hold  loop  drop   0. #>
;

\ \ Count backslashes at end of string.
\ : count-escapes ( adr len -- n)
\   tuck
\   begin
\     dup
\   while
\     1-  2dup + c@  [char] \ <>
\   until  1+
\   then  nip  - ;


: escaped?  ( c-adr len1 -- c-adr len2 flag)
  tuck
  begin
    dup
  while
    1-  2dup + c@  [char] \  <>
  until  1+
  then  ( len1 c-adr len2)
  rot over -  ( c-adr len2 count)
  2 /mod rot +  swap
;

create s"-pad 256 allot

\ Allow quotes within quotes.
: s\"
  0 s"-pad !
  begin
    [char] "  parse
    escaped?
    -rot
    s"-pad append
  while
    [char] "  s"-pad append-char
  repeat
  s"-pad count
  state @  if  postpone sliteral  then
; immediate

: .\" POSTPONE s\" POSTPONE type ; immediate 


\ \ Type string backwards.
\ : typereverse  ( c-adr len -- )
\   over +
\   begin   2dup <
\   while   c--@ emit
\   repeat  2drop ;

\ Type string backwards.
: typereverse  ( c-adr len -- )
  dup under+
  0 ?do
    c--@ emit
  loop  drop ;


\ Clear line on screen and move cursor to its beginning.
: clear-line  { y -- }
  0 y at-xy
  winwd ( n)
  \ If on bottom line, prevent scrolling.
  winht 1-  y  =  ??  1-
  spaces
  0 y at-xy ;


\ Move to bottom of screen and prepare for typing.
: bottom  winht 1-  clear-line ;

