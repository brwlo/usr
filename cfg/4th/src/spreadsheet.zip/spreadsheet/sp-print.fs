
\
\
\
\       Printing to a file.
\
\
\



\ Is ouput being redirected to a file?
0 value diverted-to-file

: divert-to-file
  handle
  if
    -1 to diverted-to-file
  else
    s" Can't divert to file; handle is null. " s" " error
    reported throw
  then ;

: undivert    0 to diverted-to-file ;

: type ( cadr len -- )
  diverted-to-file
  if
    handle
    write-file  ?dup
    if   0 to diverted-to-file
      s" Type-to-file error. " s" " error     throw
    then
  else
    type
  then ;


variable pad-for-emit

: emit ( c -- )
  diverted-to-file
  if
    pad-for-emit c!
    pad-for-emit 1 handle
    write-file   ?dup
    if   0 to diverted-to-file
      s" Emit-to-file error. " s" " error     throw
    then
  else
    emit
  then ;

: space  bl emit ;
: spaces 0 max  0 ?do  bl emit loop ;




\
\
\       Printing to file.
\
\
\

0 value typewriter-mode?
0 value printwidth

: tag  ( c-adr len --)  [char] <  emit  type  [char] >  emit ;

\ : ?tag  ( cadr len -- )
\   typewriter-mode?
\   if  2drop
\   else
\     tag
\   then ;

: tag-or-space  ( cadr len -- )
  typewriter-mode? if 2drop space else  tag  then ;

\ : nbsp typewriter-mode? if s" " else s" &nbsp;" then ;

: crlf      13 emit 10 emit ;

: typeln type crlf ;

: table(
  typewriter-mode?
  if
    s" <pre>"  typeln
  else
    s" <table  cellspacing=0  cellpadding=2  border=2 " type
    s\" align=\"center\">" typeln
  then  ;

: )table
  typewriter-mode?
  if
    s" </pre>"  typeln
  else
    s" </table>" typeln
  then  ;

: row(
  typewriter-mode?  not
  if   s" <tr>" type  then  ;

: )row
  typewriter-mode?
  if
    crlf
  else
     s" </tr>" typeln
  then  ;

\ : (slot   s" <td>" type ;
\ 
\ : slot)   s" </td>" type ;


\ create disppad 256 allot

\ Print slot.
: disp-to-file ( x y -- )  0 0 0  { x y     slotwidth width just }
  x col-widths @  to slotwidth
  x col-justify c@  to just

  typewriter-mode? not
  if
    \  Start building tag.
    s" <td " type
    \  If top row, specify relative width for each column.
    y 0=
    if
      s" width=" type
      slotwidth 100 printwidth */
      >str type
      s" % "  type
    then
    s" align=" type
  then


  x y sarray  count  -trailing
  dup \ Make sure it's not empty.
  if  over c@  [char] '  =   ( Is it a Label?)
    \
    \  Label.
    \
    if
      slotwidth just typewriter-mode? not format-label
      type
    else
    \
    \  Display floating-point number.
    \
      2drop
      \  Right justification is the default.
      just 0=  if  [char] r  to just  then
      x y farray f@
      slotwidth  just
      x col-dplaces @
      x col-commas? @
      format-float
      typewriter-mode?  not
      if
        -leading  -trailing
        just alignment type   s" >" type
      then
      type
    then
  else
    \  Empty slot.
    2drop
    typewriter-mode?
    if
      slotwidth spaces
    else      
      just alignment type     s" >" type
      nbsp type
    then
  then
  s" /td" tag-or-space
;

create title  256 allot
create printed-file  256 allot
  

: print-to-file   0 0 0 0 { remember x1 x2 promptwd }
\   s" Print to file: "
  s" Print " mypad place
  ind@  nip  1+  >str  mypad append
  s"  lines to file: " mypad append
  mypad count  dup to promptwd  bottom  type
  promptwd  printed-file mypad edit-filename
  dup 0=  if  2drop  exit  then
  2dup printed-file place
  w/o open  ?? exit
  \
  \  Find out whether we will use "<pre>" to format the output or
  \  whether we will build a table.
  \
  bottom ." Typewriter mode? (Y/n) "
  -1 to typewriter-mode?
  1 0 do
    ekey  toupper
    dup dup  [char] Y  = swap  13 =  or
    if  drop leave  then
    [char] N  = 
    if  0 to typewriter-mode?  leave  then
  0 +loop
  bottom
  s" If you want, enter title: " tuck type
  room-in-line   title  swap edit-adr
  \
  \  Find first and last non-empty column.
  \
  0 to x1
  begin
    x1 col-empty?   x1 maxsheetx <  and
  while
    x1 1+ to x1
  repeat
  maxsheetx to x2
  begin
    x2 col-empty?   x2 0 >  and
  while
    x2 1- to x2
  repeat
  x1 x2 >
  if
    s" Spreadsheet is empty. " s" " error
  else
    \
    \  Determine total of widths of columns.
    \
    0 to printwidth
    x1 x2 tidy
    do  i col-widths  @  +to printwidth  loop

    divert-to-file
    s" <html>" typeln
    title count dup
    if  s\" <h3 align=\"center\">" type type s" </h3>" typeln
    else 2drop
    then
    
    table(
      \  Print from top line down to current line.
      0 ind@ nip tidy
      do
        row(
          \  Print row number.
\       i  lmargin .r  space
          x1 x2 tidy
          do
              i j disp-to-file
          loop
        )row
      loop
    )table
    s" </html>" typeln
    diverted-to-file  to remember
    undivert
  then
  close
\   remember if  cr cr ." ---------- It was still diverted. --------" cr cr
\   else cr cr ." ------ Wasn't diverted! ------" cr    then
;


