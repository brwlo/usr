

\
\
\
\       Writing and reading files.
\
\
\




\ : emitting-to-file  ['] file-emit is emit ;
\ : normal-emitting  ['] (emit) is emit ;


: wr ( c-adr n -- )  handle write-line throw ;

\  If slot isn't empty, write its coordinates to file; on next line,
\  write contents of slot.
: wr-slot { x y }  x y sarray count ?dup if x y 2>str wr wr else drop then ;

\ Write spreadsheet to current file.
: wr-array
  kill-actions
  ['] wr-slot  is  inner-loop-action
  do-sheet ;

\ \ Get filename from user.
\ : getfname  ( cadr n -- cadr n) bottom type pad 64 accept pad swap
\   -trailing -leading ;

\  Accept filename from user, using string at permadr as default.
\  Unless empty string is entered, save string to permadr.
\  Use promtwd to calculate number of characters user is allowed to type.
: edit-filename { promptwd permadr tempadr -- cadr len }
  permadr count tempadr place
  tempadr promptwd room-in-line edit-adr
  tempadr count -trailing -leading
  dup  if  2dup permadr place  endif ;

create most-recent-file  256 allot

\ Get filename from user.
: getfname  { saving? -- c-adr n }
  most-recent-file count  mypad place
  s" Load from file: " dup >r
  s" Save to file: " dup >r
  saving?  if  2nip  else  2drop  endif
  bottom type
  \ Pass max. prompt size to edit-filename.
  2r> max  most-recent-file mypad
  edit-filename
;

\ Open a file.
: open   ( cadr len mode -- ior )
  \ When writing to a file, this program always
  \ obliterates the file and starts from scratch.  So
  \ mode w/o calls for CREATE-FILE instead of OPEN-FILE.
  dup w/o =
  if   create-file   else   open-file   then
  ?dup
  if
    nip  s" Cannot open file." s" " error
  else   to handle   0
  then ;

\ Close current file.
: close ( -- )
  handle ?dup
  if  close-file
    if s" Error while closing file." s" " error then
  then
  0 to handle ;


\  "type" does not use "emit".
\ : footest
\   s" foobar.txt" w/o  open
\   if exit then
\   emitting-to-file
\   'A emit  'B emit 'C emit 13 emit 10 emit
\   1984 4 .r
\   s" Hello." type
\   normal-emitting
\   close ;

\ Save to a file.
: save        0 { err }
  1 getfname
  dup 0=  if  2drop exit  endif
  w/o open  ?? exit

  \  Write slot widths.
  0 maxsheetx tidy
  do
    \ Write column width.
    i col-widths @  dup default-width =
    if   drop
    else
      s" #w# " mypad place
      i  2>str  mypad append
      mypad count  ['] wr catch
      if  2drop  -1 to err  leave  then
    then

    \ Write decimal places for column.
    i col-dplaces @  dup default-dplaces =
    if   drop      
    else
      s" #p# " mypad place
      i  2>str  mypad append
      mypad count  ['] wr catch
      if  2drop  -1 to err  leave  then
    then

    \ Write justification for column.
    i col-justify c@ ?dup  ( Do nothing if zero.)
    if  s" #j# " mypad place
      mypad append-char
      bl mypad append-char
      i >str  mypad append
      mypad count  ['] wr catch
      if  2drop  -1 to err  leave  then
    then

    \ Write comma-formatting status for column.
    i col-commas? @
    if  s" #,# " mypad place
      i >str mypad append
      mypad count  ['] wr catch
      if  2drop  -1 to err  leave  then
    then

  loop

  \ Write number of locked rows if not zero.
  locked-rows
  if  s" #^# " mypad place
    locked-rows >str mypad append
    mypad count  ['] wr catch
    if   2drop  -1 to err   then
  then

  err 0=  if  ['] wr-array catch  to err  then
  err
  if  s" Error while writing to file." s" " error
  else  0 to unsaved-changes
  endif
  close ;


\ : show-to-file
\   s" foobar.txt" w/o open
\   if  ." --- Can't open. ----"  exit then
\   divert-to-file
\   (show-header) 13 emit 10 emit
\   vis-rows 0
\   do  i (show-row)  13 emit 10 emit
\   loop
\   undivert
\ ;


\ Report error in line of file being read.
: line-error { c-adr len linenum -- }
  c-adr len  mypad place
  s"  in line " mypad append
  mypad count  linenum >str  error
  reported throw ;

\ Load a file.
: (fload)  1 1 0 { lines datalines ch }
  0 getfname
  ( c-adr len)
  dup 0=  if  2drop exit  endif
  init-spreadsheet
  r/o open  ?? exit
  begin
    pad 80 handle read-line ( n flag ior)
    if
      drop 0  s" Error while reading file." s" " error
      reported throw
    then
  while
    pad swap -leading
    ( c-adr len)
    \
    \  Use a do-loop as a sort of "case" control structure.
    \
    1 0 do
      2dup  s" #w#" string-prefix?
      if  ( Width and column number.)
        3 /string  2 parse-nums
        if   col-widths !
        else  2drop  s" Bad column-width data" lines  line-error
        then
        leave
      then
      2dup  s" #p#" string-prefix?
      if  ( Decimal places for column.)
        3 /string  2 parse-nums
        if   col-dplaces !
        else  2drop  s" Bad decimal-places data" lines  line-error
        then
        leave
      then
      2dup  s" #j#" string-prefix?
      if  ( Justification.)
        3 /string  -leading  ?dup
        if    over c@
              dup  s" lcra" cfind  0 < 
              if  drop 2drop s" Bad justification" lines line-error
              else  to ch   1 /string
                    1 parse-nums
                    if  ch swap col-justify c!
                    else drop s" Bad column number" lines line-error
                    then
              then
        else ( Empty string.)  drop
        then
        leave
      then
      2dup  s" #,#" string-prefix?
      if  ( Numbers in column are formatted with commas.)
        3 /string  1 parse-nums
        if  -1 swap col-commas? !
        else  drop  s" Bad column number" lines  line-error
        then
        leave
      then
      2dup  s" #^#" string-prefix?
      if  ( Number of locked rows.)
        3 /string  1 parse-nums
        if    (lock-rows)
        else  drop  s" Bad number" lines  line-error
        then
        leave
      then
      \
      \  Default.
      \
      ( If "datalines" is odd, parse slot coordinates.)
      datalines 1 and
      if  2 parse-nums
        0= >r  2dup outside?  r>  or
        if  s" Bad coordinates" lines  line-error  then
      else  strsize min ( Limit size.)  2swap sa!
      then
      1 +to datalines
    loop
    1 +to lines
  repeat  drop ;

: fload
  ['] (fload) catch
  dup
  reported <>   and
  if s" Error while reading file. " s" " error then
  close
  0 locked-rows pos!
  locked-rows  to corner_y
  compiling?  ??  compile-all
  \ "Calculate" all literals first so that formulas will have correct values
  \ with which to work.
  calc-all-literals
  calc-all
;

