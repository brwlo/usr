

: anew
  >in @
  BL word find  ( c-adr 0  |  xt true)
  if execute else drop then
  >in !   marker ;


anew spreadsheet




include ./sp-declar.fs

include ./sp-misc.fs

include ./sp-format.fs

include ./sp-sheet.fs

include ./sp-formula.fs

include ./sp-dialog.fs

include ./sp-file.fs

include ./sp-print.fs

include ./sp-copy.fs

include ./sp-move.fs



\ Gforth has these words, but the documentation doesn't.

  \ Add n2|u2 to n1|u1, giving the sum n3|u3.
  \ : UNDER+  ( n1|u1 x n2|u2 -- n3|u3 x ) ROT + SWAP ;
  \ Store a string.
  \ : place ( cadr len adr -- )




\  Spreadsheet in Gforth 0.6.2 (console mode).
\  If you're not using a DOS-box under Windows, your arrow keys may yield
\  different numbers and you'll need to change the constants.
\  Run by typing "main".  If you accidentally quit without saving your
\  work, type "mainloop" to get back to your sheet.





: chartable
  cr
  256 128 do
    i 149 = if bl else i then
    emit  i 4 .r  5 spaces
  loop ;


\ : _  34 parse  POSTPONE SLiteral (compile) type  \ postpone cr
\ ; immediate
\ 
\ : _  postpone ."
\ ; immediate
\ 
\ : help cr cr
\ ." ESC q  Quit"
\ _ ESC s  Save"
\ _ ESC l  Load"
\ cr cr
\ ;


\ \ To store a copied row or column.  Before each string is stored
\ \ the coordinates from which the string was copied.
\ create the-slice-adr
\ maxsheety maxsheetx max  1+  strsize 1+  2 cells +   *  allot
\ : the-slice ( n -- address)  strsize 1+  2 cells +   *  the-slice-adr + ;
\ 0 value slice-is-row?








\
\       Help.
\

: _   postpone .\"  postpone cr ;  immediate

: help
  page
_   ;  Copy a cell.                        [  Paste cell and move down "
_   ]  Paste cell and move right           \\  Paste cell and auto-move "
_   c  Recalculate                         C  Toggle compiled formulas "
_   p  Print to html file "
_   d  Set decimal places for column       ,  Toggle commas for column "
_   j  Set justification for column        w  Set width of column "
_   m  Set auto-move direction             ^  Lock or unlock rows "
_   HOME     Page left                     <  Lock or unlock columns "
_   END      Page right                  "
_ ESCAPE commands: "
_   q  Quit                                s  Save "
_   l  Load                                 "
_   b  Mark start of block                 k  Copy block "
_   K  Copy and clear block                p  Paste block "
_   x  Clear current column                y  Clear current row "
_   RIGHT or LEFT   Move column right or left "
_   UP or DOWN      Move row up or down "
_ Use ' to start a label. "
_ Use = to start a formula.  NOTE: all operators have equal precedence, so"
_   use parentheses to control evaluation order.  A colon (:) is used to sum a"
_   rectangular area; the formula \"=a0:c2*4\" sums 9 cells and multiplies by 4."
_   Prefix cell-reference with $ to make it absolute (unchanged when pasted)."
ekey drop   show
;


: exit-program
  unsaved-changes
  if  beep
    bottom ." There are unsaved changes ("
    unsaved-changes 1 .r ." ).  Quit anyway? "
    yn  [char] N  =  ??  exit  \ Exit this word, not the program.
  endif
  page  cr ." Type 'mainloop<ENTER>' to return to sheet." cr
  quit  ;


0 value esc-pressed

: obey ( key -- )
  esc-pressed
  if
    0 to esc-pressed
    case
      esc        of                    endof
      k-down       of     1 move-rows    endof
      k-up         of    -1 move-rows    endof
      k-right      of     1 move-cols    endof
      k-left       of    -1 move-cols    endof
      [char] q   of    exit-program    endof
      [char] s   of    save            endof
      [char] l   of    fload           endof
      [char] b   of    mark-sob  -1 to spoke               endof
      [char] B   of    mark-sob-append  -1 to spoke        endof
      [char] k   of    0 copy-block  -1 to spoke           endof
      [char] K   of    1 copy-block  -1 to spoke   show    endof
      [char] p   of    global-paste  -1 to spoke           endof
      [char] y   of    ind@ nip  clear-row  calc-all       endof
      [char] x   of    ind@ drop  clear-column  calc-all   endof
      -1 to esc-pressed
      beep
    endcase
  else
    case
      esc        of  -1 to esc-pressed         endof
      [char] ^   of  lock-rows      -1 to spoke   endof
      [char] <   of  lock-columns   -1 to spoke   endof
      [char] ,   of  toggle-commas             endof
      [char] c   of  calc-all   -1 to spoke    endof
      [char] C   of  toggle-compiling          endof
      [char] d   of  set-dec-places            endof
      [char] j   of  set-justify               endof
      [char] m   of  set-auto-move             endof
      [char] p   of  print-to-file             endof
      [char] w   of  set-width                 endof
      k-left     of  -1 0 move-rel             endof
      k-right    of  1 0  move-rel             endof
      tab        of  1 0  move-rel             endof
      k-up       of  0 -1 move-rel             endof
      k-down     of  0 1  move-rel             endof
      k-next   of  page-down                 endof
      k-prior     of  page-up                   endof
      k-end        of  page-right                endof
      k-home       of  page-left                 endof
      [char] ;   of  copy-current  -1 to spoke                 endof
      [char] [   of  paste-to-current  0 1 move-rel            endof
      [char] ]   of  paste-to-current  1 0 move-rel            endof
      [char] \   of  paste-to-current  auto-move 2@ move-rel   endof
      [char] h   of  help                                      endof
      13         of  0 edit-slot  auto-move 2@ move-rel        endof
      dup  s" =-+.'0123456789" cfind  -1 >
      if    dup edit-slot  auto-move 2@  move-rel
      else  beep
      endif
    endcase
  endif
;

: mainloop
  depth { correctdepth }
  0 0 pos!  0 copied !  at-current  show
  0 to esc-pressed
  begin
    \ Check stack depth.
    assert(  depth correctdepth =  )

    ekey ( Get key.)
     \ $FFFF and \ Needed because numbers from arrow keys
                                \ may be different on different computers.
    0 to spoke

    obey

    esc-pressed
    if  bottom ." ESC"
    else
      spoke 0=
      if  bottom ind@ 2dup .slotname sarray count type
      endif
      at-current
    endif
    \ Empty keyboard buffer.
    begin ekey? while ekey drop repeat

  again ;


: main    page
  empty-copied-array
  0 most-recent-file !
  0 printed-file !
  0 title !
  init-spreadsheet
  
  1 0 auto-move 2!      \ Move right.
  0 0 start-of-block 2!
  0 0 end-of-block 2!
  9999 9999 copied-corner 2!
  decimal

  mainloop ;
