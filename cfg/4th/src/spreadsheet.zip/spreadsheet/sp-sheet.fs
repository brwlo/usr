

: !defaults  { x }
  default-width    x col-widths !
  default-dplaces  x col-dplaces !
  0                x col-commas? !
  0                x col-justify ! ;



\ //////////////////////////////////////////////////////////////

defer before-inner-loop
defer after-inner-loop
defer inner-loop-action

\  This will be set to do-sheet-rowwise or do-sheet-columnwise.
defer do-sheet

: kill-actions
  ['] drop  dup
  is before-inner-loop
  is after-inner-loop
  ['] 2drop  is  inner-loop-action ;


: do-sheet-rowwise
  0 maxsheety upto
  do
    i before-inner-loop
    0 maxsheetx upto
    do
      i j  inner-loop-action
    loop
    i after-inner-loop
  loop ;

: do-sheet-columnwise
  0 maxsheetx upto
  do
    i before-inner-loop
    0 maxsheety upto
    do
      j i  inner-loop-action
    loop
    i after-inner-loop
  loop ;



\ //////////////////////////////////////////////////////////////



defer whicharray

: fa! ( F:f x y -- F:f )  farray fdup f! ;
: fill-f-array ( F:f -- )
  kill-actions
  ['] fa!  is  inner-loop-action
  do-sheet-rowwise   fdrop ;

\ Store string in string-array.
: sa! ( cadr n x y -- )  sarray place ;

: empty-slot ( x y -- )  whicharray 0 swap ! ;

: empty-array
  kill-actions
  ['] empty-slot  is  inner-loop-action
  do-sheet-rowwise ;

: empty-sarray  ['] sarray  is  whicharray   empty-array ;
: empty-copied-array  ['] sarray-copied  is  whicharray   empty-array ;

: calc-maxcorners
  maxsheety maxrow - locked-rows +  to  maxcorner_y ;

\ Store current column and row.
: pos!  currentpos 2! ;
: pos@  currentpos 2@ ;




: row-empty? { y -- flag }
  0
  0 maxsheetx upto do  i y sarray c@ +  loop
  0= ;

: col-empty? { x -- flag }
  0
  0 maxsheety upto do  x i  sarray c@ +  loop
  0= ;


\ Holds number of columns now visible.
variable (vis-cols)

: (count-vis-cols) ( room low high -- room )
  ( low high) upto
  ?do
    \ Each column, even the leftmost, is preceded by a gutter character
    \ or a space; so we add 1 for that.
    i col-widths @ 1+
    2dup
    >=
    if  -   1 (vis-cols) +!
    else  drop  leave
    then
  loop ;

: count-vis-cols { n1 -- n2 } \ If col. n1 is the first col. of the
                              \ sheet shown on the screen after the
                              \ locked columns, how many
                              \ columns will fit?
  0 (vis-cols) !
  winwd lmargin -

  0 locked-cols 1- (count-vis-cols)
  n1 maxsheetx     (count-vis-cols)
  drop
  (vis-cols) @  ;

: current-vis-cols  corner_x count-vis-cols ;




\ Are coordinates outside of spreadsheet?
: outside? ( x y -- flag)
  over  0 maxsheetx clamp
  over  0 maxsheety clamp
  d<> ;

\ Are coordinates in locked part of spreadsheet?
: locked-zone? ( x y -- flag)
  locked-rows <   swap
  locked-cols <   or ;

\ Convert window slot-coordinates to array-coordinates.
\ Must make allowances for locked rows and columns.
: col>x
  dup
  locked-cols >=
  if
    corner_x +  locked-cols -
  then ;
: row>y
  dup
  locked-rows >=
  if
    corner_y +  locked-rows -
  then ;

: >indices  ( col row -- x y )
  swap  col>x  swap row>y ;

\ Get indices of current slot.
: ind@  pos@  >indices ;




\
\
\       Display spreadsheet.
\
\
\

: maketween  pad c!  pad 1  postpone sliteral ; immediate

\ Between columns
\ : tween [ '` ] maketween ;
\ : tween [ '~ ] maketween ;
\ : tween [ 183 ] maketween ;  \ Bullet.
\ : tween [ 186 ] maketween ;  \ Small circle.
\ : tween [ 176 ] maketween ;  \ Tiny, faint circle.
\ : tween [ 254 ] maketween ;  \ underscore
\ : tween [ 166 ] maketween ;  \ Thick vertical bar.
\ : tween s" �" ;
\ : tween s" _" ;
: tween s" |" ;


\ : .empty ( width -- )   0 ?do  '.  emit  loop ;
\ : .empty ( width -- )   0 ?do  bl  emit  loop ;
: .empty ( width -- )   blanks swap type ;
: .empty ( width -- )   spaces ;

\ Print `name' of slot followed by ">"; e.g., "D63>".
\ : .slotname { x y -- }  x 'A + emit y 1 .r ." >"  ;
: make-slotname  ( x y -- c-adr len)
  0 pad !
  swap  [char] A  +  pad append-char
  >str pad append
  [char] >  pad append-char  pad count ;
: .slotname ( x y --) make-slotname type ;


\ : head ( col -- )  ?dup if  corner_x + 64 + slotwd 2/
\   else  32 1  then  spaces emit ;

variable disp-wd-total


: head  ( col --)   0 0 0 0 0 { col    x c width before after }  
  space
  col  col>x  to x
  x  [char] A  +  to c ( Calculate letter to show.)
  x col-widths @  to width
  width 2/  to before
  width before - 1-  to after
  s"  ----------------------------------------------------------" drop
\   s"  �����������������������������������������������������������" drop
  dup before typereverse    ( Leading characters for centering.)
  c emit   after type  ( Trailing characters.)
  width 1+ disp-wd-total +!   ;




\ \ Move cursor to specified slot.
\ : at-slot ( col row -- )  swap 1- slotwd * 2 + 0 max swap at-xy ;





\ Move cursor to specified slot.
: at-slot { col row -- }
  lmargin
  locked-cols col min  0
  ?do
    i col-widths @  +
    1+  ( Add one for space between columns.)
  loop
  col  locked-cols  max    locked-cols
  ?do
    i corner_x + locked-cols -  col-widths @  +
    1+  ( Add one for space between columns.)
  loop
  1+  ( Move out of gutter.)
  row  1+ ( Add 1 for header.)
  at-xy  ;



\ !!!!!!!!!!!!!

\  For debugging.
0 value disp-x
0 value disp-y

\ Display slot.
: disp ( x y -- )  0 0 { x y     width just }
  \  For debugging.
  x to disp-x   y to disp-y

  x col-widths @  to width
  x col-justify @  to just
  x y sarray  count  dup
  if  over c@   [char] '  =   ( Is it a Label?)
    if 
        width just 0 format-label  type
    else
    \
    \  Display floating-point number.
    \
      2drop
      \ Default justification is "right".
      just 0= if   [char] r  to just  then
      x y farray f@
      width  just
      x col-dplaces @
      x col-commas? @
      format-float  type
    then
  else  ( Empty slot.)
    2drop  width .empty
  then
  \ To keep track of how much has been printed on row.
  width disp-wd-total +!   ;


: show-slot  ( col row --)
  >indices  disp  ;

: (show-header)
  lmargin spaces
  current-vis-cols 0 ?do  i head  loop ;

: show-header
  lmargin disp-wd-total !
  0 0 at-xy
  (show-header)
  winwd disp-wd-total @ - spaces   ;

: (show-row)  { row -- }
  \ Show row number.
  0 row >indices   lmargin .r  drop
  lmargin disp-wd-total !
  \  Don't show column separator before first column.
  tween nip blanks swap
  current-vis-cols 0 do
    type  tween nip disp-wd-total +!
    i  row  show-slot
    tween
  loop   2drop  ;

: show-row ( row -- )
  0
  over 1+ ( Add 1 for header.) at-xy
  (show-row)
  ( Now clear to end of row.)
  winwd disp-wd-total @ - spaces  ;

\ Move cursor to current slot.
: at-current  pos@ at-slot ;

\ Update screen.
: show
  show-header
  vis-rows  0
  do  i show-row
  loop
  at-current ;







\ While column that ought to contain the cursor is outside of our view,
\ slide our view one column at a time in direction determined by dx.
: swivel  ( dx -- )  \ dx is -1, 0, or 1.
  pos@ drop   { dx col }
  \ Widths of columns vary, so we have to be careful.
  begin
    col locked-cols current-vis-cols within  not
  while
    dx +to corner_x
    dx negate +to col
  repeat
  col pos@ nip pos!
;


\ ***********************
\ *  New
\ ***********************
\ Move to another slot. Section of spreadsheet shown may have to be shifted.
: move-rel ( dx dy -- )
  0 0 { dx dy  col row }

  \ Make sure we're not moving out of bounds.
  ind@   dx dy  pairs+  2dup  ( x y x y)
  outside?   -rot   ( flag x y)
  locked-zone?   or
  ??  exit

  pos@  dx dy  pairs+
  to row   to col

  \ Put current corner coordinates on stack.
  corner_x corner_y

  \ Calculate how far row is outside screen-boundaries.
  row  locked-rows maxrow clamp  row -
  dup  negate +to corner_y   +to row

  col row pos!

  \ Now that we've changed col by dx, we want to
  \ make dx -1, 0, or 1 so that we can shift the sheet 1 column
  \ at a time if column isn't on the screen.
  dx  -1 1 clamp  swivel

  corner_x corner_y  d<> if ( View has shifted.)  show  then
  at-current  ;





\ Given array indices x,y, move to correct slot on screen.  Section of
\ sheet shown on screen may have to be shifted.
: move-to-indices { x y -- }
  x corner_x -  locked-cols +  y corner_y -  locked-rows +
  pos@  pairs-
  move-rel ;



\ : to-corner  locked-cols locked-rows pos!  at-current ;

: page-left
  pos@ drop  locked-cols =
  if    locked-cols to corner_x   show
  else  locked-cols  pos@ nip  pos!  at-current
  then  ;

: page-right
  \ Is cursor already at right edge of screen?
  pos@ drop  current-vis-cols 1-  =
  if    maxsheetx  pos@ >indices nip  move-to-indices
  else  (vis-cols) @ 1-  pos@ nip  pos!  at-current
  then  ;

: page-up
  pos@ nip  locked-rows =
  \ If cursor is already as high as it can go on screen, page up.
  if
    corner_y vis-rows - locked-rows +  locked-rows  max  to corner_y
    show
  else
    \ Move cursor as high as it can go.
    pos@ drop locked-rows pos!  at-current
  then  ;

: page-down
  pos@ nip  maxrow  =
  if
    corner_y vis-rows + locked-rows -  maxcorner_y  min  to corner_y
    show
  else
    pos@ drop maxrow pos!  at-current
  then  ;





: init-spreadsheet
  kill-actions
  ['] do-sheet-rowwise  is  do-sheet
  0.0e fill-f-array
  empty-sarray
  \  Fill formula-xts array with zeroes.
  ['] formula-xts  is  whicharray   empty-array
  0 maxsheetx upto
  do
    i !defaults
  loop
  0 to locked-rows
  calc-maxcorners
  0 to corner_x
  0 to corner_y
  0 0 pos!
  0 to unsaved-changes
  0 to compiling?
;





\
\
\
\       Locking columns.
\
\
\

: (lock-columns)  (  num_cols_to_lock  -- )
  (vis-cols) @ 1- min  ( Must be less than # of visible columns.)
  to locked-cols
  calc-maxcorners
  locked-cols  to corner_x ;

: lock-columns
  locked-cols
  if   \ Unlock.
    corner_x  locked-cols -   to corner_x
    0 to locked-cols
    \ The columns that replace the locked columns on the screen may be
    \ wider, and so we may need to shift our view to the right to keep
    \ the current column on the screen.
    1 swivel

    calc-maxcorners
    show
    bottom ." Unlocked."
  else
    corner_x 0 <>
    if
      s" Leftmost col. of sheet must be displayed in order to lock. " s" " error
      bottom
      exit
    then
    pos@ drop
    ?dup
    0=
    if
      s" Move just past the last column to be locked. " s" " error
      bottom
      exit
    then
    (lock-columns)
    bottom
    ." Locked "  locked-cols dup .  ." column"
    1 > if ." s" then ." ."
  then
;


\
\
\
\       Locking rows.
\
\
\

: (lock-rows)  (  num_rows_to_lock  -- )
  vis-rows 1- min  ( Must be less than # of visible rows.)
  to locked-rows
  calc-maxcorners
  locked-rows  to corner_y ;

: lock-rows
  locked-rows
  if  \  Unlock.
    corner_y  locked-rows -   to corner_y
    0 to locked-rows
    calc-maxcorners
    show
    bottom ." Unlocked."
  else
    corner_y 0 <>
    if
      s" Top of sheet must be displayed in order to lock. " s" " error
      bottom
      exit
    then
    pos@ nip
    ?dup
    0=
    if
      s" Move just below the last row to be locked. " s" " error
      bottom
      exit
    then
    (lock-rows)
    bottom
    ." Locked "  locked-rows dup .  ." row"
    1 > if ." s" then ." ."
  then
;
