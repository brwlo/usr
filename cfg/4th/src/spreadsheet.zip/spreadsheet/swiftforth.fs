\ SwiftForth compatibility layer by Marcel Hendrix <14801536153560@frunobulax.edu>

INCLUDING-OPTION C:\ForthInc\SWIFTFORTH\LIB\OPTIONS\` Fpmath.f
: FORM  GET-SIZE SWAP ; ( -- lines cols )
1 FLOATS CONSTANT FLOAT
1 CELLS  CONSTANT CELL
: TOUPPER ( c -- C ) $DF AND ;
: BEEP  1000 200 beep DROP ;
\ edit-line       c-addr n1 n2 -- n3         gforth       ``edit-line''
\ edit the string with length n2 in the buffer c-addr n1, like accept. 
 : .BS ( lim addr n char -- lim addr n' ) DROP  DUP IF  1-  8 EMIT BL EMIT 8 EMIT  THEN ;
 : .ESC ( lim addr n char -- lim addr 0 ) DROP  BEGIN  DUP WHILE 0 .BS REPEAT ;
 : .RETURN ( lim addr n char -- n addr -1 ) DROP -ROT NIP -1 ;
 : .ACCEPTED ( lim addr n char -- lim addr n' ) FOURTH THIRD = IF  DROP  EXIT  THEN  BL MAX  DUP EMIT  THIRD THIRD + C!  1+ ;
 : ASTROKE ( lim addr n char -- lim addr n )
   DUP 127 >  IF  DROP      EXIT  THEN
   DUP   8 =  IF  .BS       EXIT  THEN
   DUP  13 =  IF  .RETURN   EXIT  THEN
   DUP  27 =  IF  .ESC      EXIT  THEN
   .ACCEPTED ;

: EDIT-LINE ( c-addr lim u -- n ) 
  SWAP -ROT 2DUP TYPE 
  BEGIN ( lim addr n ) DUP 0< 0= WHILE  AKEY ASTROKE  REPEAT 2DROP ;

: utime ( -- us ) COUNTER #1000 UM* ;
: STRING-PREFIX? ( c-addr1 u1 c-addr2 u2 -- f ) TUCK 2>R MIN 2R> COMPARE 0= ;
: UNDER+ ROT + SWAP ; ( a b x -- a+x b )
: ENDIF  POSTPONE THEN ; IMMEDIATE
: D<>    D- OR 0= 0= ;
: F<>    F= 0= ;
: 0>=    0< 0= ;

#65576 CONSTANT k-down
#65574 CONSTANT k-up
#65573 CONSTANT k-left
#65575 CONSTANT k-right
#65569 CONSTANT k-next
#65570 CONSTANT k-prior
#65571 CONSTANT k-end
#65572 CONSTANT k-home

include ./compat/assert.fs
include ./compat/anslocal.fs
include ./sp.fs