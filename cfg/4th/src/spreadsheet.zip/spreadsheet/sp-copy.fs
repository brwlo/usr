

\
\
\
\       Copy and paste a cell.
\
\




2variable form-offset
0 value formula-changed?

\ Is the slot-reference relative?
0 value relative?

\ As characters are tacked on to mypad, look for slot reference and
\ adjust it, unless it starts with "$".
: ,,      { ch -- }
  pad @
  if   \ We've already started parsing a slot-reference.
    ch is-digit
    if  ch pad append-char   0 to ch
    else
       pad count
       ref ( x y)
       relative?
       if
         form-offset 2@ d+   2dup outside?
         if
           s" Adjusted reference would be out of bounds." s" " error
           reported throw
         then
         -1 to formula-changed?
       endif
       swap  [char] a  +  mypad append-char
       >str
       mypad append
       0 pad !
       \ If current char. is ":", we're processing a range-reference, and we
       \ don't want to change the state of "relative?".
       ch  [char] :  <>  if   -1 to relative?   endif
    then
  else
    ch is-alpha
    if  ch pad append-char   0 to ch
    else
      ch  [char] $  <>  to relative?
    endif
  then
  ch if  ch mypad append-char  then ;




\  Adjust slot-references when pasting so that they have the same relation
\  to the destination slot that they did to the source slot, unless they
\  are absolute (begin with $).
: fix-formula ( c-adr1 len1 fromx fromy x y -- c-adr2 len2 )
  { fromx fromy x y }
  0 to formula-changed?
  over c@  [char] =  <>  over 0=  or
  ?? exit   \ If string is null or doesn't start with =, return.
  0 pad !   0 mypad !   -1 to relative?
  x y  fromx fromy  d-  form-offset 2!
  bounds  do
    i c@   ,,
  loop
  0 ,,
  mypad count  ;


: copy-slot ( x y --)  2dup  copied-from 2!   sarray count  copied  place  ;
: copy-current  ind@ copy-slot  bottom ." Copied." ;


\ Same as "place", but increments "unsaved-changes" if new contents are
\ different from old.
: place-in-slot  { cadr len stradr -- }
  cadr len stradr count  compare
  if  1 +to unsaved-changes
      cadr len stradr place
  endif
;

: formula-to-new-slot  { c-adr len oldx oldy x y -- }
  c-adr len oldx oldy x y
  ['] fix-formula  catch
  if   2drop 2drop 2drop   c-adr len   then
  ( c-adr len)  to len  to c-adr
  c-adr len  x y sarray  place-in-slot
  compiling?
  if
    formula-changed?
    if
      c-adr len  calc-str fdrop    formula
    else
      oldx oldy formula-xts  @
    then
  else
    \ Simply wipe out old execution token for this slot.
    0
  then
  x y formula-xts  !
;

: paste-to-slot { x y }
  copied count
  copied-from 2@  x y
  formula-to-new-slot ;

: paste-to-current  ind@  paste-to-slot  update-current ;




\
\
\
\       Copying blocks.
\
\
\

: (copy-block)  { x0 y0 x1 y1 cut? }
  y0 y1 tidy do
    x0 x1 tidy do
      i j outside?  not
      if
        i j sarray  count
        i j sarray-copied  place
        cut?
        if   0  i j sarray  !
             0  i j formula-xts  !
        then
      then
    loop
  loop ;

2variable start-of-block
2variable end-of-block
2variable copied-corner

: mark-sob
  ind@
  2dup    start-of-block 2!
  copied-corner 2!
  empty-copied-array
  bottom ." Start of block marked." ; 

: mark-sob-append
  ind@
  2dup    start-of-block 2!
  copied-corner 2@  ( x1 y1 x0 y0)
  \ Possibly update copied-corner.
  rot min  -rot min  swap
  copied-corner 2!
  bottom ." Start of block marked for appending." ; 

: copy-block  { cut? }  
  ind@  end-of-block 2!
  start-of-block 2@
  end-of-block 2@
  cut? (copy-block)
  bottom ." Block copied." ;


: (global-paste)  0 0 0 { xoffset yoffset       newx newy outofbounds -- }
  maxsheety 1+ 0 do
    maxsheetx 1+ 0 do
      i j sarray-copied  count
      dup
      if
        i xoffset +  to newx
        j yoffset +  to newy
        newx newy outside?
        if  2drop   1 +to outofbounds
        else
          ( cadr len)
          i j newx newy formula-to-new-slot
          
          \ Set width of destination column to equal that of source.
          i col-widths @
          (  newx col-widths @  max )
          newx col-widths !
        then
      else  2drop
      then
    loop
  loop
  outofbounds
  if  outofbounds >str
      s"  cells weren't pasted since they were out of bounds." error
  endif
;


\ Copy all non-empty slots from sarray-copied to sarray.
: global-paste
  copied-corner 2@
  -1 -1 d<>
  if
    ind@   copied-corner 2@
    ( x1 y1 x0 y0) 
    rot - negate
    -rot - swap
    (global-paste)
    calc-all
  then ;


