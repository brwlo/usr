\ iForth compatibility layer by Marcel Hendrix <89241137153560@frunobulax.edu>
S" iforth" ENVIRONMENT? 
  [IF]  DROP  
	: FORM  L/SCR C/L ; ( -- lines cols )
	1 FLOATS CONSTANT FLOAT
	1 CELLS  CONSTANT CELL
	: TOUPPER ( c -- C ) >UPC ;
	: BEEP  ^G emit ;
	\ edit-line       c-addr n1 n2 -- n3         gforth       ``edit-line''
	\ edit the string with length n2 in the buffer c-addr n1, like accept. 
	: EDIT-LINE ( c-addr1 n1 n2 -- n3 ) SWAP SINGLE$ NIP ; 
	: PLACE ( c-addr1 u1 addr2 -- ) PACK DROP ;
	: utime ( -- us ) MS?  #1000 UM* ;
	: 2NIP ( a b c d -- c d ) 2SWAP 2DROP ;
	: STRING-PREFIX? ( c-addr1 u1 c-addr2 u2 -- f ) TUCK 2>R MIN 2R> COMPARE 0= ;
        : IS STATE @ IF POSTPONE [IS] ELSE  POSTPONE IS  ENDIF ; IMMEDIATE
	--v  CONSTANT k-down
	--^  CONSTANT k-up
	<--  CONSTANT k-left
	-->  CONSTANT k-right
	PgUp CONSTANT k-next
	PgDn CONSTANT k-prior
	End  CONSTANT k-end
	Hme  CONSTANT k-home

        include ./compat/anslocal.fs
        include ./compat/assert.fs
    [THEN] 

include ./sp.fs