

\
\
\
\     Moving rows and columns.
\
\
\


: find-empty-row   0 { y dy    flag --  y2 -1 | 0 }
  begin
    y row-empty? not
  while
    dy +to y
    0 y outside?
    if   0  exit  then
  repeat
  y -1 ;

: find-empty-col   0 { x dx    flag --  x2 -1 | 0 }
  begin
    x col-empty? not
  while
    dx +to x
    x 0 outside?
    if   0  exit  then
  repeat
  x -1 ;

\ : empty-row { y -- flag }
\   0 maxsheetx tidy do  0  i y sarray !  loop  ;

: move-row  { y dy  }
  0 maxsheetx tidy do
    i y copy-slot    i  y dy + paste-to-slot
    0  i y sarray ! 
  loop  ;



: move-col  0 { x dx      newx }
  x dx +  to newx
  x col-widths @   newx col-widths !
  x col-dplaces @  newx col-dplaces !
  x col-commas? @  newx col-commas? !
  x !defaults
  0 maxsheety tidy do
    x i copy-slot   newx i paste-to-slot
    0  x i sarray !
  loop  ;



: move-things  0  { diff pos find-empty-thing move-thing      last-p -- }
  pos diff +  diff  find-empty-thing execute
  if  diff -  to last-p
    silence!
    \ Move last first so that it won't be overwritten.
    diff +to last-p
    begin
      last-p diff - to last-p
      last-p diff move-thing execute
      pos last-p =
    until
    calc-all
    talk!
  else
    s" No empty space. " s" " error
  then ;

: move-rows { direction }  direction  ind@ nip  ['] find-empty-row
  ['] move-row
  move-things   0 direction move-rel ;
: move-cols { direction }  direction  ind@ drop  ['] find-empty-col
  ['] move-col
  move-things   direction 0 move-rel ;





: clear-row  { y }
  0 y outside?  if  s" This row is out of bounds: " y >str error  exit  then
  0 maxsheetx tidy
  do
    0  i y sarray  !
  loop
;

: clear-column  { x }
  x 0 outside?
  if  s" This column is out of bounds: " x >str error  exit  then
  0 maxsheety tidy
  do
    0  x i sarray  !
  loop
  x !defaults
;

