
: room-in-line ( n -- )
  winwd - negate 2 - ;

: star-line ( y -- )
  clear-line
  stars winwd 1-  type ;




create errmess1 256 allot
create errmess2 256 allot
0 value silent

\ Write error message.
:noname ( cadr1 n1 cadr2 n2 | cadr1 n1 0 c -- )
  silent
  if  errmess2 place  errmess1 place
  else   beep
    0 star-line
    winht 2 -  star-line
    bottom   2swap  type
    over if type else nip emit then
    ."   Press a key:"  ekey drop
    \ Restore header.
    show-header
    \ Restore last row of spreadsheet.
    winht 3 ( Allow for header.) -  show-row
  then
;
is error

: silence!  1 to silent   0 errmess1 !   0 errmess2 ! ;
: talk!  0 to silent  errmess1 count  dup
  if  errmess2 count  error  else  2drop  then ;




\ : parse-nums?  ( cadr len wanted -- n1 ... flag)
\   { wanted }
\   wanted parse-nums
\   wanted = ;

\ Accept and parse 1 or more numbers separated by spaces.
: get-nums
  { wanted  maxchars  -- n1 ... flag }
  pad maxchars accept
  pad swap  wanted  parse-nums  ;




: set-auto-move  ( -- )
  0 0 { len numbers }
  bottom ." Direction (01 is down, 10 is right)? "
  \ Accept up to 2 digits and 2 minus signs.
  pad 4 accept
  to len
  len 0=  ??  exit
  0 mypad !
  pad len  bounds
  do
    i c@  dup
    s" -+ 0123456789" cfind
    0<  if  drop  s" Bad input. " s" " error  unloop exit  endif
    dup mypad append-char
    is-digit
    if   bl  mypad  append-char   endif
  loop
  mypad count  0  parse-nums    to numbers
  numbers 0=  ??  exit
  numbers 2 >
  if  numbers 2 do  drop  loop
  endif
  numbers 1 =
  if
    \ Since only 1 number was entered, use reasonable default for 2nd.
    dup  if  0  else  1  endif
  endif
  
  auto-move 2!
;



\
\
\
\       Let user change column settings.
\
\
\


: set-dec-places  ( -- )
  bottom
  ." Decimal places for this column?  Current value is "
  ind@ drop col-dplaces @  .
  1 2 get-nums
  if
    dup   0 10 within
    if
        ind@ drop col-dplaces !  show
    else  drop  s" Get serious. " s" " error  then
  else
    drop
  then ;

\ Set width of current column.
: set-width  ( -- )
  bottom ." Width for this column? (Maximum is "
  max-width 1 .r   ." .) "
  ind@ drop col-widths @
  ." Current value: " .
  pad 2 accept
\   ?dup  0=  if  exit  then
  ?dup  0=  ?? exit
  pad swap 1 parse-nums
  if  ?dup 0=
    if  s" Can't set to 0. " s" " error  exit  then
    dup max-width >
    if  drop  s" Exceeds maximal width, which is " max-width >str error
    else
      ind@ drop col-widths !  show
    then
  else
    drop  s" Bad number. " s" " error
  then ;

: set-justify
  bottom ." Justification for this column? (l,c,r,a=auto) "
  ind@ drop col-justify c@
  [char] a max
  ." Current value: " emit space
  0
  begin
    drop ekey dup  s\" lcra\r"  cfind
    -1 >
  until
  dup 13 = if drop exit then
  dup  [char] a  = if drop 0 then
  ind@ drop col-justify c!
  show
;

: toggle-commas ( -- )
  ind@ drop dup
  col-commas? @  0=
  swap col-commas? !
  show  ;



\ When user edits slot, in the line above print "....." to show
\ him how much of what he types will be displayed in the spreadsheet.
: width-guide  ( offset column --)
  col-widths @
  winht 2 -  clear-line
  swap spaces  space  \ One extra for the beginning "'" of a label.
  [char] -  copies  type ;


\  Let user edit contents of slot.
\  : edit-slot
\ :noname  ( c -- )
\   ind@  2dup sarray
\   { ch    x y sadr }
\   \  Make copy of current contents.
\   sadr count mypad place
\   \ Show name of slot we're editing.
\   x y make-slotname  ( c-adr len)
\   dup x width-guide \ Let user see how much of what he types will be displayed.
\   bottom type
\   ch  ( Has 1 char. already been typed?)
\   if   1 sadr c!   ch  sadr 1+  c!   endif
\   sadr strsize edit-adr
\   0  x y formula-xts  !     \ Wipe-out any existing compiled formula.
\   x y  ['] calc-slot  catch  ?dup
\   if  -rot 2drop  reported <>  \ Does error need to be reported?
\     if  sadr 1+ c@  [char] =  =  \ Is first character "="?
\       if s" "  else  s"  (Use = for formulas, ' for labels.)"  endif
\       s" Bad cell." 2swap error
\     endif
\     -1 +to unsaved-changes ( Because of recursion.)
\     0 recurse
\   endif
\   \ Don't increment unsaved-changes or compile unless contents have changed.
\   mypad count   sadr count   compare
\   if
\     1 +to unsaved-changes
\     \ Show that old xt is invalid.
\     0  x y formula-xts  !
\     compiling?
\     if   x y compile-slot   then
\   endif
\   \ Restore row used by "width-guide".
\   winht  3 - ( Allow for header.)  show-row
\   at-current   pos@ show-slot
\ ;
\ is edit-slot


:noname  ( c -- )
  ind@  2dup sarray
  0 { ch    x y sadr   saved-compiling? }
  \  Make copy of current contents.
  sadr count mypad place
  \ Show name of slot we're editing.
  x y make-slotname  ( c-adr len)
  dup x width-guide \ Let user see how much of what he types will be displayed.
  bottom type
  ch  ( Has 1 char. already been typed?)
  if   1 sadr c!   ch  sadr 1+  c!   endif
  sadr strsize edit-adr
  0  x y formula-xts  !     \ Wipe-out any existing compiled formula.
  compiling? to saved-compiling?
  \  Make sure compiling? is off so that we can calculate slot.
  0 to compiling?
  x y  ['] calc-slot  catch  ?dup
  if  -rot 2drop  reported <>  \ Does error need to be reported?
    if  sadr 1+ c@  [char] =  =  \ Is first character "="?
      if s" "  else  s"  (Use = for formulas, ' for labels.)"  endif
      s" Bad cell." 2swap error
    endif
    0 recurse
  else
\    quit \ // // // // // // // // // //
    saved-compiling? to compiling?
    compiling?
    if   x y compile-slot   then
    \ Don't increment unsaved-changes unless contents have changed.
    mypad count   sadr count   compare
    if
      1 +to unsaved-changes
    endif
    \ Restore row used by "width-guide".
    winht  3 - ( Allow for header.)  show-row
    at-current   pos@ show-slot
  then
;
is edit-slot



