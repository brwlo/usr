

decimal   \ Initialize constants.
\ 80  constant  winwd
\ 25  constant  winht
: winwd form nip ;
: winht form drop ;
3   constant  lmargin  \ For showing row numbers.
winht 2 -  constant  vis-rows

10  constant  default-width
30  constant  max-width
2   constant  default-dplaces
\ 11  constant  slotwd
\ winwd 2 - slotwd / 1+  constant  viscols
31  constant  strsize
299 constant  maxsheety
25  constant  maxsheetx
\ Bounds for slot coordinates of section of spreadsheet shown on screen.
\ viscols 1-      constant  maxcol
vis-rows 1-  constant  maxrow

0 value maxcorner_y
0 value locked-rows
0 value locked-cols

27 constant esc          9 constant tab




2variable currentpos
0 value corner_x
0 value corner_y \ The cell shown in upper, left corner.
create mypad 256 allot
947 constant reported  \ Magic number for throwing.
create copied 256 allot  \ To store what was copied.
2variable copied-from  \ Slot that was copied.

create stars   winwd allot  stars  winwd  char *  fill
create blanks  winwd allot  blanks winwd bl fill

2variable auto-move  ( How to move cursor after user-input.)
0 value unsaved-changes



\ : calc-display-bounds
\ \   vis-rows  locked-rows  -  to free-rows
\   vis-rows 1-  to maxrow
\   maxsheety maxrow - locked-rows +  to  maxcorner_y
\   locked-rows  to corner_y
\ ;



: not  s" 0=" evaluate ; immediate

\ Store bytes without count and adjust "here".
: store-bytes  ( cadr len -- )
  tuck  here swap move allot ;



: 2dim-navigate  ( x y adr -- adr)
  dup @  ( x y adr size)
  >r  dup cell+ @  ( x y adr width)
  rot *  rot +  r> * +
  2 cells + ;

: 2dim-array  ( x y itemsize --)
  create
  dup ,  rot dup ,
  * * allot
  does>  2dim-navigate ;



\
\
\  Now the arrays that hold the spreadsheet.
\  sarray holds the strings that the user input.
\  farray holds the floating-point numbers into which those
\  strings are translated.
\
\

\ maxsheety 1+ maxsheetx 1+ * dup
\ create sarrayadr  strsize 1+ * allot
\ create farrayadr  floats allot
\ 
\ : sarray ( x y -- address)  maxsheetx 1+ *   +   strsize 1+ *  sarrayadr + ;
\ : farray ( x y -- address)  maxsheetx 1+ *   +   floats        farrayadr + ;

maxsheetx 1+  maxsheety 1+  2dup 2dup 2dup
strsize 1+  2dim-array  sarray
strsize 1+  2dim-array  sarray-copied
float       2dim-array  farray
cell        2dim-array  formula-xts  \ For compiled formulas.




: integerarray  create  dup 1- ,  cells allot
  does> ( i adr) swap  over @ ( adr i max)  over <
  abort"  Exceeded size of integer array."
  cells + cell+ ;

maxsheetx 1+  integerarray  col-widths
maxsheetx 1+  integerarray  col-dplaces
maxsheetx 1+  integerarray  col-commas?
maxsheetx 1+  integerarray  col-justify


\ Handle for output file.
0 value handle

defer error
defer edit-slot
  ' abort dup
  is error
  is edit-slot


\ Used by mainloop.  Set to true if routine called from menu wrote a message
\ that shouldn't be overwritten by the mainloop.
0 value spoke

\ Are we using compiled formulas?
0 value compiling?



