\ REPRESENT 
\ ( c-addr u -- n flag1 flag2 ) (F: r -- ) or ( r c-addr u -- n flag1 flag2 ) 
\ 
\ At c-addr, place the character-string external representation of the
\ significand of the floating-point number r. Return the decimal-base
\ exponent as n, the sign as flag1 and valid result as flag2. The
\ character string shall consist of the u most significant digits of the
\ significand represented as a decimal fraction with the implied decimal
\ point to the left of the first digit, and the first digit zero only if
\ all digits are zero.
\
\  The significand is rounded to u digits following
\  the round to nearest rule; n is adjusted, if necessary, to correspond to
\  the rounded magnitude of the significand.
\
\ If flag2 is true then r was in
\ the implementation-defined range of floating-point numbers. If flag1 is
\ true then r is negative. 




\
\
\       Formatting.
\
\




create justifypad   256 allot

\ Justify a string; if parameter "just" isn't l, c, or r,
\ c is assumed.
: justify   0 { cadr len width just     room -- cadr len ]
  len width >=
  if  cadr len  exit  then
  justifypad width bl fill
  width len -  to room
  \  Move string to blank-filled pad.
  cadr
  justifypad
  room 2/
  [char] l  just =
  if
    drop  0
  else
  [char] r  just =
  if  drop  room
  then then
  +
  len move
  justifypad width ;




\ : .val ( F:f width decimalplaces -- )  { width decimalplaces }
\   decimalplaces
\   if
\     width decimalplaces 1 f.rdp
\   else
\     fround f>d d>s  width .r
\   then ;




\ create format-integer-pad   256 allot

\ : format-double  ( d width commaformated? -- cadr len)
\   0 0 { width commas?      charcount digcount }
\   swap over dabs  \ Leave signed integer on bottom.
\   <#
\     #  1 to digcount  1 to charcount
\     begin
\       2dup 0. d>
\     while
\       commas?
\       if
\         digcount 3 mod 0=
\         if  ', hold  charcount 1+ to charcount   then
\       then
\       #
\       digcount 1+ to digcount
\       charcount 1+ to charcount
\     repeat
\     rot   dup 0<  if  charcount 1+ to charcount  then
\     sign
\     begin
\       charcount width <
\     while
\       bl hold
\       charcount 1+ to charcount
\     repeat
\   #> ;
\ \   format-integer-pad place
\ \   format-integer-pad count  ;

\ : format-single  ( n width commaformated? -- cadr len)
\   rot  s>d  2swap  format-double ;

\ : .r  0 format-single type ;



\ : fracpart  ( F:float -- F:float)
\   fabs fdup floor f- ;
\ 
\ : fracpart-format ( F:float decimalplaces -- cadr len)
\   1.0e f+
\   dup 2 +  swap ( width decplaces)
\   1 f>str-rdp
\   1 /string ( Chop off the leading "1".)   ;






\ : format-float ( F:float width just decimalplaces commaformatted? -- cadr len)
\   { width just places commas? }
\   0 format-float-pad !
\   fdup
\   places 0=
\   if  fround  f>d
\   else
\     f>d
\     \  Place "-" for negative floats whose abs. value is < 1.
\     \  Otherwise, -0.39 would become 0.39.
\     dup  0=
\     fdup 0.0e f<   and
\     if  s" -" format-float-pad place  then
\   then
\ 
\   1 commas? format-double  ( cadr len)
\   format-float-pad append
\   places
\   if
\     fdup fracpart places fracpart-format
\     format-float-pad append
\   then
\   format-float-pad  c@  width >
\   if
\     \ \ \  cr ." Too wide. "  fdepth .  cr
\     \ Too wide for slot.
\     width places 1 f>str-rdp
\   else
\     fdrop
\     format-float-pad count  width just  justify
\   then ;



\ Execute "hold" if flag is true and c <> 0.
: ?hold  ( flag c --)
  swap
  if
    ?dup  ??  hold
  else    drop
  then ;

\ Don't make the number of digits passed needlessly large:
\ -1.14e pad 9 represent  2drop drop pad 9 type 114000000 ok
\ -1.14e pad 20 represent  2drop drop pad 20 type 11399999999999999023 ok


\ : format-float ( F:float width just decimalplaces commaformatted? -- cadr len)
\   0 0 0 { width just dplaces comma    exp neg tail }
\   \ Get enough digits.
\     \ See how many digits are in integer portion.
\   fdup f>d dabs 2dup d0=
\   if   drop   else   <# #s #> nip   then
\     \ Add decimal places.
\   dplaces +    1 max ( Need at least 1 digit.)
\   format-float-pad swap represent ( exponent sign success)
\   0=
\   if  \ Failure!  Return asterisks.
\     2drop
\     width [char] * copies
\   else
\     ( exp sign)
\     to neg  to exp   ( exp may be negative!)
\     comma  if  [char] ,  to comma  endif
\     <#
\       \ Get address of rightmost digit and keep it on the stack
\       \ through both loops (while decrementing it).
\       dplaces exp +  1-  format-float-pad  +
\       dplaces
\       if
\         \ If exp is negative, we'll have to supply the 0's that are
\         \ just to the right of the decimal point.
\         exp 0 min  dup
\         dplaces + 1-
\         do
\           i -1 >
\           if   c@-   else   [char] 0   then
\           hold
\           -1
\         +loop
\         [char] .  hold
\       then
\       exp 0>
\       if
\         exp 1+  1 do
\           c@- hold
\           i 3 mod 0=    \ Comma every 3 digits...
\           i exp <  and  \ ...if there will be numeral to its left.
\           comma  ?hold
\         loop
\       then
\       drop  \ Discard address.
\       neg sign
\       0.  \ Double number to be dropped by "#>".
\     #>
\   endif
\   width just  justify ;

create format-float-pad   256 allot

: format-float ( F:float width just decimalplaces commaformatted? -- cadr len)
  0 0 0 { width just dplaces comma    exp neg tail }
  \ Get enough digits.
    \ See how many digits are in integer portion.
  fdup f>d dabs  <# #s #>  nip
    \ Add decimal places.
  dplaces +    1 max ( Need at least 1 digit.)
  format-float-pad swap represent ( exponent sign success)
  0=
  if  \ Failure!  Return asterisks.
    2drop
    width  [char] *  copies
  else
    ( exp sign)
    to neg  to exp   ( exp may be negative!)
    comma  if  [char] ,  to comma  endif
    <#
      \ Get address of rightmost digit and keep it on the stack
      \ through both loops (while decrementing it);
      \ actually, starts as adr+1.
      dplaces exp +   format-float-pad  +  ( address)
      dplaces
      if
        \ If exp is negative, we'll have to supply the 0's that are
        \ just to the right of the decimal point.
        exp 0 min  dup
        dplaces + 1-
        do
          i -1 >
          if   c--@   else   [char] 0   then
          hold
          -1
        +loop
        [char] .  hold
      then
      exp 0>
      if
        exp 1+  1 do
          c--@ hold
          i 3 mod 0=    \ Comma every 3 digits...
          i exp <  and  \ ...if there will be numeral to its left.
          comma  ?hold
        loop
      then
      drop  \ Discard address.
      neg sign
      0.  \ Double number to be dropped by "#>".
    #>
  endif
  width just  justify ;


: f.formatted ( F:float width just decimalplaces commaformatted? -- )
  format-float  type ;


\ : format-label  ( cadr len width just -- cadr len )
\   { width just }
\   1 /string
\   width min  -trailing
\   width just justify
\ ;


\ For html.
: alignment  ( c -- cadr len)
  case
    [char] c  of  s\" \"center\""  endof
    [char] l  of  s\" \"left\""    endof
    [char] r  of  s\" \"right\""   endof
    s\" \"center\""   rot
  endcase ;

: nbsp  s" &nbsp;" ;

: format-label  ( cadr len width just html? -- cadr len )
  { width just html? }
  1 /string  \ Remove initial apostrophe.
  -trailing
  html?
  if
    just alignment  mypad place
    s" >" mypad append
    \  Convert each leading space to "&nbsp;".
    begin
      over c@ bl =
    while
      nbsp  mypad append
      1 /string
    repeat
    mypad append
    mypad count
  else
    width min  \ Truncate to slot-width.
    width just justify
  then
;


