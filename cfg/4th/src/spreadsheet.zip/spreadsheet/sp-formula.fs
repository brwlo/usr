0 value formula


\ : 2fliterals  ( F: r1 r2 --)
\   fswap  postpone fliteral  postpone fliteral ; immediate

\ : 2literals  ( n1 n2 --)
\   swap  postpone literal  postpone literal ; immediate


\ Add up a rectangular area of the spreadsheet.
: sumrange ( x1 y1 x2 y2 -- F:sum) rot tidy { a b } tidy { c d }
  0.0e  a b do  c d  do  i j farray  f@  f+  loop loop  ;


\ Is string a slot reference (does it begin with letter)?
: ref? ( cadr n -- cadr n flag) over c@ is-alpha ;


\ Convert slot reference (e.g., "j35") to x,y.
: ref    0 { adr len err -- x y }
  adr c@ toupper  [char] A  -
  len 2 <  to err
  0.  adr len  1 /string  >number  nip
  err or
  if  s" Bad reference: " adr len error  reported throw
  endif
  d>s   2dup outside?
  if   s" Out-of-bounds reference: " adr len  error
    reported throw
  endif ;


\ Get value of slot to which string refers.
: doref ( cadr len -- F:f)  -1 { adr len p }
  [char] :  adr len cfind  to p ( If ":" found, it's a range.)
  p -1 >
  if  adr p ref  ( x y)
      compiling?
      if   postpone 2literal   then
      adr p + 1+  len p - 1-  ref? not  throw
      ref  ( x1 y1 x2 y2)
      compiling?
      if
         postpone 2literal  ['] sumrange  compile,
         0.0e  \ Dummy float for error-checking.
      else
        sumrange
      then
  else
    adr len ref  farray
    compiling?
    if
      postpone literal  ['] f@  compile,
      0.0e  \ Dummy float for error-checking.
    else
      f@
    then
  endif ;



: store-digits  ( cadr len --)
  begin dup
  while over c@
    [char] 0  -    (  Convert to number.)
    c,  1 /string
  repeat
  2drop ;



\  Make f= yield floating-point result (1.0 or 0.0).
: wrap__f=  f=  abs  s>d d>f ;

\  Make f<> yield floating-point result (1.0 or 0.0).
: wrap__f<>  f<>  abs  s>d d>f ;

\ Operators recognized (@ is absolute value, ! is !=).
\ Followed by: How many operands for each operator?
: ops             s" */+-^@=!()" ;
create  opsargs   s" 2222212201"   store-digits

create optable
  ' f* ,  ' f/ ,  ' f+ ,  ' f- ,  ' f** ,  ' fabs ,  ' wrap__f= ,
  ' wrap__f<> ,

: opfind ( c -- n)  ops cfind ;
: op? ( c -- flag)  opfind -1 > ;

\ A stack for operators.
create opstack   256 cells allot  opstack cell - value sp
: push sp cell+ to sp  sp ! ;
: copy sp @ ;
: pop  copy  sp cell - to sp ;
-1 push   -1 push


\ Execute operator.
: run   0 { op-index      numargs -- }
  opsargs  op-index + c@  dup to numargs
  fdepth >
  if  s" Shortage of operands for "
      0  ops drop op-index + c@  error   reported throw
  then
  op-index cells optable + @
  compiling?
  if
    \  Discard floats that merely served for error checking;
    \  leave one because each operand would leave one.
    \  The floats that our compiled operand will need have
    \  already been compiled using "fliteral".
    numargs 1-  0 max
    0 ?do   fdrop   loop
    compile,
  else
    execute
  then  ;

\  For the sake of speed.
char (  opfind  constant  "("-index
char )  opfind  constant  ")"-index

0 value prev-op

: doop  { op-index }
  op-index "("-index =
  if  op-index push
    exit
  then
  begin
    copy 0>=   copy "("-index <>   and
  while
    pop run
  repeat
  op-index ")"-index  =     \  !!!! What if there was no "("?  !!!!
  if  copy "("-index =   if   pop drop   then
  else
    op-index   0>=  if   op-index push   then
  then
  op-index to prev-op ;


: doval  { op-index adr len -- }
  len if
    adr len ref?
    if  doref
    else  >float  0=
      if  s" Bad float: " adr len  error  reported throw  then
      \  When compiling, floats are still put on the stack
      \  (in addition to being compiled) for the sake of error-checking.
      compiling?
      if   fdup  postpone fliteral   then
    then
  then
  op-index doop ;



\ Clear floating-point stack.
: clearfstack  begin  fdepth 0>  while  fdrop  repeat ;


create  infix-pad    256 allot

: infix ( cadr len -- F:f)
  0 0 0 { cadr len     ch err op-index }
  clearfstack   0 infix-pad !   0 to prev-op
  compiling?
  if
    :noname   \ Start compiling a nameless definition; when finished, its
              \ execution token will be put on the stack by ";".
  then
  cadr len bounds
  ?do   i c@ to ch
    ch opfind  to op-index
    \ Determine if character is an operator.
    op-index 0>=
    if
      \  If it's a unary + or -, it's not an operator after all.
      \  If no number is being built in the infix-pad, and if
      \  previous operator wasn't ")", then a + or - is unary.
      infix-pad @ 0=  \ and
      prev-op ")"-index <>
      and
      if 
        ch s" +-" cfind  -1 >
        if
          0
        else
          -1
        then
      else
        -1
      then
    else
      0
    then
    if  \  We have an operator.
      \ Convert infix-pad to float, run stacked operator, and push this operator.
      op-index  infix-pad count  ['] doval  catch
      ?dup
      if
        to err  drop 2drop  leave
      endif
      0 infix-pad !
    else  \ Not operator.
      \ If blank or $ (indicates absolute reference), ignore.
      ch BL <>   ch [char] $ <>   and
      if   ch infix-pad append-char  endif
    endif
  loop
  err 0=
  if
    \ Force evaluation of residue.
    -1  infix-pad count
\     2dup  cr ." Char. is " ch emit ."   Residue is " type cr
    ['] doval  catch
    ?dup  if  to err  drop 2drop  then
  endif
  compiling?
  if
    postpone ;
    to formula
  then
  \ Error if operator left on opstack.
  copy 0>=
  if
    begin  pop drop copy  -1 =
    until
    s" Operator left on opstack." s" " error
    0 to formula
    reported throw
  endif
  err 0=
  if   fdepth 1 >
    if
      s" More than 1 float left on stack. " s" " error
      0 to formula
      reported throw
    then
  else
    0 to formula
    err throw
  endif ;



\ Just for fun, we'll count how many formulas we process during
\ recalculation and compilation of the spreadsheet.
variable formula-count



: compile-slot { x y -- }
  \ If there's already an execution-token for this slot, we assume
  \ it has already been compiled and we do nothing.
  x y formula-xts @  0=
  if
    x y sarray  count  ( c-adr len)   2dup  swap
    \  If 1st character is "=", and len <> 0, it's a formula.
    c@  [char] =   =
    and
    if
      1 formula-count +!
      -1 to compiling?     \ Make sure "infix" compiles.
      1 /string            \ Remove leading "=".
      infix   clearfstack
      formula              \ XT of formula.
    else
      2drop
      0      \ Use 0 for execution token.
    then
    x y formula-xts  !
  then ;


: calc-str ( c-adr len -- F:r)   0 { adr len    ch }
  len
  if  adr c@   to ch
    \ Label?
    [char] '  ch  =  if   0.0e   exit  then
    \ Formula?
    [char] =  ch  =
    if
      adr len  1 /string  infix
      1 formula-count +!
      exit
    then
    \ Literal number.
    adr len  >float
    0=
    if  s" Bad floating-point number. " s" " error  reported throw  then
  else
    0.0e   
  then ;



: calc-slot  { x y -- }
  compiling?
  if
    x y formula-xts  @
    ?dup  \ Make sure it's not 0.
    if
      execute  0
      1 formula-count +!
    else
      -1
    then
  else
    -1
  then
  if
    x y sarray  count  calc-str
  then
  x y farray  f! ;

\ Used immediately after loading spreadsheet from file to "calculate"
\ literals so that formulas will have correct values with which to work.
: calc-literal  ( x y -- )
  0 0 0 { x y   adr len ch }
  x y sarray  count  to len  to adr
  len
  if  adr c@   to ch
    \ Label?
    [char] '  ch  =   ??   exit
    \ Formula?
    [char] =  ch  =   ??   exit
    \ Literal number.
    adr len  >float
    0=
    if  s" Bad floating-point number. " s" " error  reported throw  then
    x y farray  f!
  then ;

: calc,edit_error { x y -- }
  x y  ['] calc-slot  catch
  ?dup
  if  -rot 2drop
    reported <> if  s"  * * * Bad cell. * * * " s" " error  then
    x y move-to-indices
    0 edit-slot
    \  Wipe out any compiled formula for this slot.
    0  x y formula-xts  !
  then ;

\ Used immediately after loading spreadsheet from file to "calculate"
\ literals so that formulas will have correct values with which to work.
: calc-literal,edit_error { x y -- }
  x y  ['] calc-literal  catch
  ?dup
  if  -rot 2drop
    reported <> if  s"  * * * Bad cell. * * * " s" " error  then
    x y move-to-indices
    0 edit-slot
  then ;

: calc-all  bottom ." Calculating..."
  0 formula-count !
  utime  \ Put current time in microseconds on stack.
  kill-actions
  ['] calc,edit_error  is  inner-loop-action
  do-sheet
  utime  d- dnegate  1000 um/mod nip
  bottom
  ." ...calculated "
  formula-count @ dup  .
  ." formula"   1 <>  if  ." s"  then
  ."  in "  .  ." milliseconds."
  show ;

\ Used immediately after loading spreadsheet from file to "calculate"
\ literals so that formulas will have correct values with which to work.
: calc-all-literals
  kill-actions
  ['] calc-literal,edit_error  is  inner-loop-action
  do-sheet
;


: compile-all
  -1 to compiling?
  0 formula-count !
  bottom ." Compiling..."
  utime  \ Put current time in microseconds on stack.

  kill-actions
  ['] compile-slot  is  inner-loop-action
  do-sheet

  utime  d- dnegate  1000 um/mod nip
  bottom
  ." ...compiled "
  formula-count @ dup  .
  ." formula"   1 <>  if  ." s"  then
  ."  in "  .  ." milliseconds."
;

: update-current  ind@ calc-slot  at-current  pos@ show-slot ;

: toggle-compiling
  compiling?
  if
    0 to compiling?   bottom ." Compiling off."
  else
    -1 to compiling?   compile-all
  then   -1 to spoke ;
